from django.apps import AppConfig


class GoldAppConfig(AppConfig):
    name = 'gold_app'
