from django.urls import path 
from . import views 

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('' , views.Creat_user),
    path('results', views.Show_info),
    path('succsess' , views.success)
]
